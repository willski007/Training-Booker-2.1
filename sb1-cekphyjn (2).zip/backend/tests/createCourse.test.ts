import { describe, it, expect, vi } from 'vitest';
import { createCourse } from '../functions/courses/createCourse';

// Mock Supabase client
vi.mock('@supabase/supabase-js', () => ({
  createClient: () => ({
    auth: {
      getUser: () => Promise.resolve({ data: { user: { id: 'test-user-id' } } }),
    },
    from: () => ({
      select: () => ({
        eq: () => ({
          single: () => Promise.resolve({ data: { role: 'instructor' } }),
        }),
      }),
      insert: () => ({
        select: () => ({
          single: () => Promise.resolve({
            data: {
              id: 'test-course-id',
              title: 'Test Course',
              description: 'Test Description',
              price: 9900,
              capacity: 10,
              location: 'Test Location',
              start_date: '2024-04-01T10:00:00Z',
              end_date: '2024-04-01T12:00:00Z',
            },
          }),
        }),
      }),
    }),
  }),
}));

describe('createCourse', () => {
  it('should create a course successfully', async () => {
    const request = new Request('http://localhost/courses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Test Course',
        description: 'Test Description',
        price: 9900,
        capacity: 10,
        location: 'Test Location',
        startDate: '2024-04-01T10:00:00Z',
        endDate: '2024-04-01T12:00:00Z',
      }),
    });

    const response = await createCourse(request);
    const data = await response.json();

    expect(response.status).toBe(201);
    expect(data).toHaveProperty('id');
    expect(data.title).toBe('Test Course');
  });
});