import { describe, it, expect, vi } from 'vitest';
import { handleStripeWebhook } from '../functions/webhooks/stripeWebhook';
import Stripe from 'stripe';

// Mock Stripe
vi.mock('stripe', () => ({
  default: vi.fn(() => ({
    webhooks: {
      constructEvent: vi.fn(() => ({
        type: 'payment_intent.succeeded',
        data: {
          object: {
            id: 'pi_test123',
            amount: 9900,
          },
        },
      })),
    },
  })),
}));

// Mock Supabase client
vi.mock('@supabase/supabase-js', () => ({
  createClient: () => ({
    from: () => ({
      update: () => ({
        eq: () => Promise.resolve({ error: null }),
      }),
    }),
  }),
}));

describe('handleStripeWebhook', () => {
  it('should handle payment_intent.succeeded event', async () => {
    const request = new Request('http://localhost/webhook/stripe', {
      method: 'POST',
      headers: {
        'stripe-signature': 'test_signature',
      },
      body: JSON.stringify({
        type: 'payment_intent.succeeded',
        data: {
          object: {
            id: 'pi_test123',
            amount: 9900,
          },
        },
      }),
    });

    const response = await handleStripeWebhook(request);
    const data = await response.json();

    expect(response.status).toBe(200);
    expect(data).toEqual({ received: true });
  });
});