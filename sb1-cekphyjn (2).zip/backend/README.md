# Training Booker Backend

This is the backend service for the Training Booker platform, providing API endpoints and database management for the training marketplace.

## Structure

```
/backend
├── /functions          # Serverless functions
│   ├── /courses       # Course management endpoints
│   ├── /bookings      # Booking management endpoints
│   └── /webhooks      # External service webhooks
├── /migrations        # Database migrations
├── /tests            # Test files
└── /types            # TypeScript type definitions
```

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Run tests:
   ```bash
   npm test
   ```

## Database Migrations

Migrations are managed through Supabase and can be found in the `/migrations` directory. Each migration is versioned and contains both up and down SQL scripts.

## Testing

Tests are written using Vitest and can be run using:
```bash
npm test
```

For coverage reports:
```bash
npm run test:coverage
```

## Environment Variables

Required environment variables:
- `SUPABASE_URL`: Your Supabase project URL
- `SUPABASE_ANON_KEY`: Your Supabase anonymous key
- `STRIPE_SECRET_KEY`: Your Stripe secret key
- `STRIPE_WEBHOOK_SECRET`: Your Stripe webhook secret