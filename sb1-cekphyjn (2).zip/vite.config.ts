// vite.config.js (in your project root)
import path from 'path';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      // If 'frontend/src' is where your code lives,
      // update the path accordingly:
      '@': path.resolve(__dirname, 'frontend/src'),
    },
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
});
