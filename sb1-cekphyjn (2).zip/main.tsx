import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './frontend/src/utils/App';

import './frontend/src/utils/index.css';
import 'https://unpkg.com/@tailwindcss/browser@4';
import './frontend/src/utils/App.css';

createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
