import React from 'react';
import ErrorBoundary from '../components/error_handling/ErrorBoundary';
import Landing from '../components/consumer/Landing';
import Header from '../components/default/global/Header';

function App() {
  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-background">
        <main>
          <Header />
          <Landing />
        </main>
      </div>
    </ErrorBoundary>
  );
}

export default App;
