import React from 'react';
import { Button } from '@/components/ui/button';
import logoDark from '@/assets/logo_dark.svg';

const Header = () => {
  return (
    <header className="global-header">
      <div className="mx-auto flex h-14 w-full max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo Container - Now with proper sizing */}
        <div className="flex-shrink-0">
          <a href="/" aria-label="Home" className="block w-auto">
            <img
              src={logoDark}
              alt="Training Booker Logo"
              className="h-8 w-auto"
            />
          </a>
        </div>

        {/* Navigation Items - Now with proper spacing and responsive behavior */}
        <div className="flex items-center gap-2 sm:gap-4 lg:gap-6">
          <button
            type="button"
            className="hidden sm:inline-flex items-center text-sm button-ghost"
          >
            <span role="img" aria-label="Money Bag" className="mr-2">
              💰
            </span>
            <span>Promote Your Class</span>
          </button>
          <button type="button" className="button-ghost text-sm px-3 py-2">
            Log In
          </button>
          <button type="button" className="button-secondary text-sm px-4 py-2">
            Join for Free
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;