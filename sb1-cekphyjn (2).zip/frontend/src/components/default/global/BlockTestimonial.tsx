import React from 'react';

const BlockTestimonial: React.FC = () => {
  return (
    <article className="max-w-sm rounded-lg border p-4 border-radius-16 text-card-foreground light-panel">
      {/* Testimonial Headline */}
      <h4 className="mb-4">{`{Testimonial Headline}`}</h4>

      {/* Testimonial Body */}
      <p className="mt-3 text-sm text-muted-foreground">
        Nulla consequat massa quis enim. Donec pede justo, fringilla vel,
        aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet
        a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium.
        Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi.
      </p>

      {/* Student Info */}
      <div className="mt-4 flex items-center space-x-2">
        {/* Avatar */}
        <img
          src="https://via.placeholder.com/32"
          alt="Student avatar"
          className="h-8 w-8 rounded-full object-cover"
        />
        {/* Name */}
        <span className="text-sm font-medium">{`{Student}`}</span>
      </div>
    </article>
  );
};

export default BlockTestimonial;
