import React from 'react';

const CardCourse: React.FC = () => {
  return (
    <article className="flex w-full max-w-xl overflow-hidden rounded-lg border bg-card shadow">
      {/* Left side: Course Image */}
      <div className="w-2/5">
        <img
          src="https://res.cloudinary.com/db0ejdewy/image/upload/v1739659225/th_placeholder_course_xvu364.jpg"
          alt="Course"
          className="h-full w-full object-cover"
        />
      </div>

      {/* Right side: Course Details */}
      <div className="flex-1 p-4">
        <h4 className="text-sm font-semibold leading-tight">
          {`{Course Title – It's A Really Long Name and It's Huge}`}
        </h4>
        <p className="mt-1 text-xs text-muted-foreground">Orlando, FL</p>
        <p className="mt-2 text-sm">
          <span className="font-medium">Starts March 21, 2025</span> | 11:00AM
        </p>

        {/* Stats */}
        <div className="mt-3 flex items-center space-x-6 text-sm">
          <div className="flex items-center space-x-1">
            {/* Replace with your own icon or SVG */}
            <span role="img" aria-label="Approval Rating">
              👍
            </span>
            <span>96%</span>
          </div>
          <div className="flex items-center space-x-1">
            {/* Replace with your own icon or SVG */}
            <span role="img" aria-label="Duration">
              ⏰
            </span>
            <span>4 Hours</span>
          </div>
        </div>
      </div>
    </article>
  );
};

export default CardCourse;
