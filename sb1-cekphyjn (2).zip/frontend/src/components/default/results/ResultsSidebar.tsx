import React, { useState } from 'react';

const categoriesList = [
  'Professional',
  'Technology and AI',
  'Healthcare',
  'Skilled Trades',
  'Wellness',
  'Education',
  'Security',
  'Language',
];

function ResultsSidebar() {
  // Text/number fields
  const [topic, setTopic] = useState('');
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [location, setLocation] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');

  // Toggles
  const [toggles, setToggles] = useState({
    oneOnOne: false,
    youth: false,
    certificateProvided: false,
    materialsProvided: false,
    jobPlacement: false,
    networking: false,
    employerSponsorship: false,
  });

  // Handle adding/removing categories from the selection
  const handleCategoryToggle = (category) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(
        selectedCategories.filter((cat) => cat !== category)
      );
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };

  // Handle toggles
  const handleToggleChange = (e) => {
    const { name, checked } = e.target;
    setToggles((prev) => ({
      ...prev,
      [name]: checked,
    }));
  };

  // Clear all filters
  const clearAll = () => {
    setTopic('');
    setSelectedCategories([]);
    setLocation('');
    setStartDate('');
    setEndDate('');
    setMinPrice('');
    setMaxPrice('');
    setToggles({
      oneOnOne: false,
      youth: false,
      certificateProvided: false,
      materialsProvided: false,
      jobPlacement: false,
      networking: false,
      employerSponsorship: false,
    });
  };

  // Apply filters (you can customize how this data is used)
  const applyFilters = () => {
    // In a real app, you'd typically pass these values to a parent component or API
    console.log({
      topic,
      selectedCategories,
      location,
      startDate,
      endDate,
      minPrice,
      maxPrice,
      toggles,
    });
  };

  return (
    <div className="w-64 p-4 bg-white rounded-md shadow-md">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-semibold text-lg">Filter by</h2>
        <button onClick={clearAll} className="text-blue-600 hover:underline">
          Clear All
        </button>
      </div>

      {/* Topic */}
      <div className="mb-4">
        <label className="block text-sm font-medium mb-1">Topic</label>
        <input
          type="text"
          placeholder="I want to learn..."
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          className="w-full p-2 border rounded"
        />
      </div>

      {/* Categories (Multi-select) */}
      <div className="mb-4">
        <label className="block text-sm font-medium mb-1">Categories</label>
        <div className="border rounded p-2">
          {categoriesList.map((category) => (
            <div key={category} className="flex items-center mb-2">
              <input
                type="checkbox"
                id={category}
                checked={selectedCategories.includes(category)}
                onChange={() => handleCategoryToggle(category)}
                className="mr-2"
              />
              <label htmlFor={category} className="text-sm">
                {category}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Location */}
      <div className="mb-4">
        <label className="block text-sm font-medium mb-1">Location</label>
        <input
          type="text"
          placeholder="City, ST"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="w-full p-2 border rounded"
        />
      </div>

      {/* Date Range */}
      <div className="flex mb-4 space-x-2">
        <div className="flex-1">
          <label className="block text-sm font-medium mb-1">Start Date</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>
        <div className="flex-1">
          <label className="block text-sm font-medium mb-1">End Date</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>
      </div>

      {/* Price Range */}
      <div className="flex mb-4 space-x-2">
        <div className="flex-1">
          <label className="block text-sm font-medium mb-1">Min. Price</label>
          <input
            type="number"
            placeholder="Any"
            value={minPrice}
            onChange={(e) => setMinPrice(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>
        <div className="flex-1">
          <label className="block text-sm font-medium mb-1">Max. Price</label>
          <input
            type="number"
            placeholder="Any"
            value={maxPrice}
            onChange={(e) => setMaxPrice(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>
      </div>

      {/* Toggles */}
      <div className="mb-4">
        <span className="block text-sm font-medium mb-1">Only Show:</span>
        {/* 1-on-1 Training */}
        <div className="flex items-center mb-2">
          <input
            type="checkbox"
            id="oneOnOne"
            name="oneOnOne"
            checked={toggles.oneOnOne}
            onChange={handleToggleChange}
            className="mr-2"
          />
          <label htmlFor="oneOnOne" className="text-sm">
            1-on-1 Training
          </label>
        </div>
        {/* Youth */}
        <div className="flex items-center mb-2">
          <input
            type="checkbox"
            id="youth"
            name="youth"
            checked={toggles.youth}
            onChange={handleToggleChange}
            className="mr-2"
          />
          <label htmlFor="youth" className="text-sm">
            Youth
          </label>
        </div>
        {/* Certificate Provided */}
        <div className="flex items-center mb-2">
          <input
            type="checkbox"
            id="certificateProvided"
            name="certificateProvided"
            checked={toggles.certificateProvided}
            onChange={handleToggleChange}
            className="mr-2"
          />
          <label htmlFor="certificateProvided" className="text-sm">
            Certificate Provided
          </label>
        </div>
        {/* Materials Provided */}
        <div className="flex items-center mb-2">
          <input
            type="checkbox"
            id="materialsProvided"
            name="materialsProvided"
            checked={toggles.materialsProvided}
            onChange={handleToggleChange}
            className="mr-2"
          />
          <label htmlFor="materialsProvided" className="text-sm">
            Materials Provided
          </label>
        </div>
        {/* Job Placement Assistance */}
        <div className="flex items-center mb-2">
          <input
            type="checkbox"
            id="jobPlacement"
            name="jobPlacement"
            checked={toggles.jobPlacement}
            onChange={handleToggleChange}
            className="mr-2"
          />
          <label htmlFor="jobPlacement" className="text-sm">
            Job Placement Assistance
          </label>
        </div>
        {/* Networking Opportunities */}
        <div className="flex items-center mb-2">
          <input
            type="checkbox"
            id="networking"
            name="networking"
            checked={toggles.networking}
            onChange={handleToggleChange}
            className="mr-2"
          />
          <label htmlFor="networking" className="text-sm">
            Networking Opportunities
          </label>
        </div>
        {/* Employer Sponsorship */}
        <div className="flex items-center">
          <input
            type="checkbox"
            id="employerSponsorship"
            name="employerSponsorship"
            checked={toggles.employerSponsorship}
            onChange={handleToggleChange}
            className="mr-2"
          />
          <label htmlFor="employerSponsorship" className="text-sm">
            Employer Sponsorship
          </label>
        </div>
      </div>

      {/* Apply Filters */}
      <button
        onClick={applyFilters}
        className="w-full bg-blue-500 text-white p-2 rounded mt-4"
      >
        Apply Filters
      </button>
    </div>
  );
}

export default ResultsSidebar;
