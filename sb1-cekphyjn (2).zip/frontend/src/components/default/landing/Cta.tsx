import React from 'react';

const Cta: React.FC = () => {
  return (
    <section className="py-5 bg-foreground text-background text-center section-half dark-panel border-radius-16">
      <div className="mx-auto max-w-2xl px-4">
        {/* Headline */}
        <h2 className="text-3xl font-bold md:text-4xl">
          Stop Searching. Start Learning.
        </h2>

        {/* Subheadline */}
        <p className="mt-2 text-sm md:text-base">
          Find your perfect in-person course today!
        </p>

        {/* CTA Button */}
        <div className="mt-6">
          <button className="button-secondary px-6 py-3 text-sm md:text-base">
            Explore All Classes
          </button>
        </div>
      </div>
    </section>
  );
};

export default Cta;
