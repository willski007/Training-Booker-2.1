import React from 'react';

// Example data for your image cards.
// Replace the placeholder images with real assets (e.g., imported .jpg/.png/.svg).
const solutionCards = [
  {
    label: 'Personal Development & Wellness',
    image:
      'https://res.cloudinary.com/db0ejdewy/image/upload/v1739658774/th_personal_development_cgvsqm.jpg',
  },
  {
    label: 'Technology & AI',
    image:
      'https://res.cloudinary.com/db0ejdewy/image/upload/v1739658774/th_tech_and_ai_dxnnkb.jpg',
  },
  {
    label: 'Skilled Trades',
    image:
      'https://res.cloudinary.com/db0ejdewy/image/upload/v1739658775/th_skilled_trades_xczpxi.jpg',
  },
  {
    label: 'Language',
    image:
      'https://res.cloudinary.com/db0ejdewy/image/upload/v1739658774/th_language_upi1cf.jpg',
  },
];

const Solution: React.FC = () => {
  return (
    <section className="py-12 bg-background text-foreground">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 px-4 md:flex-row">
        {/* Left Side: 2x2 Grid of Cards */}
        <div className="grid w-full grid-cols-1 gap-4 sm:grid-cols-2 md:w-2/3">
          {solutionCards.map((card) => (
            <div
              key={card.label}
              className="relative aspect-[16/9] overflow-hidden rounded-lg shadow-lg"
            >
              <img
                src={card.image}
                alt={card.label}
                className="absolute h-full w-full object-cover"
              />
              <div className="absolute bottom-0 left-0 w-full bg-black/50 p-2 text-sm text-white">
                {card.label}
              </div>
            </div>
          ))}
        </div>

        {/* Right Side: Heading & Description */}
        <div className="flex flex-col justify-center md:w-1/3">
          <h2 className="text-3xl font-bold leading-tight md:text-4xl">
            Hands-On Learning Made Easy. No More Guesswork!
          </h2>
          <p className="mt-4 text-sm text-muted-foreground md:text-base">
            No more hours wasted searching. We connect you with trusted,
            expert-led in-person courses designed to help you gain real skills,
            get hired faster, or master your craft. Hands-on, structured, and
            frustration-free.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Solution;
