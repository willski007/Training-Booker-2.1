import React from 'react';

/**
 * Example categories—adjust as needed.
 * Each item shows a label and course count.
 */
const categories = [
  { label: 'Business', count: 33 },
  { label: 'Tech & AI', count: 33 },
  { label: 'Medical', count: 33 },
  { label: 'Trades', count: 33 },
  { label: 'Wellness', count: 33 },
  { label: 'Education', count: 33 },
  { label: 'Creative', count: 33 },
  { label: 'Security', count: 33 },
  { label: 'Language', count: 33 },
];

const AboveTheFold: React.FC = () => {
  return (
    <section className="section-wrapper py-10 bg-background text-center">
      <div className="mx-auto max-w-4xl px-4 section-center">
        {/* Headline */}
        <h1 className="text-3xl font-bold leading-tight md:text-4xl mb-80">
          Stop Searching. Start Learning.
        </h1>
        <p className="mt-4 text-sm text-muted-foreground md:text-base subheading">
          Ditch the guesswork. Learn from top instructors in hands-on, in-demand
          courses designed to accelerate your career.
        </p>

        {/* Search Bar */}
        <div className="mt-6 mb-12 flex flex-col items-center justify-center gap-2 md:flex-row">
          <div className="topic-search">
            <input
              type="text"
              placeholder="I want to learn..."
              className="w-full max-w-sm rounded border px-3 py-2 focus:outline-none md:w-auto topic-search-input"
            />
            <input
              type="text"
              placeholder="near (City)"
              className="w-full max-w-sm rounded border px-3 py-2 focus:outline-none md:w-auto topic-search-input"
            />
            <button className="button-primary px-6 py-2 text-sm md:text-base topic-search-button">
              Find Classes
            </button>
          </div>
        </div>

        {/* Category Section */}
        <h2 className="mt-8 text-xl font-semibold md:text-2xl">
          Explore 300+ in-demand classes near you
        </h2>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat.label}
              type="button"
              className="button-tertiary px-4 py-2 text-sm md:text-base flex flex-col items-center space-y-1 category-search-button"
            >
              <span className="text-small font-bold">{cat.label}</span>
              <span className="text-tiny">{cat.count} Courses</span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboveTheFold;
