import React from 'react';

const HowItWorks = () => {
  return (
    <section className="py-12 bg-background text-foreground section-half">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 py-7 dark-panel border-radius-16">
        {/* Row 2: Steps (displayed horizontally) */}
        <div className="flex flex-row items-center justify-between space-x-8 w-full">
          {/* Step 1 */}
          <div className="flex flex-col items-center p-1">
            <h3 className="font-bold leading-tight">
              3 Simple Steps to Find the Right Training
            </h3>
            <p className="mt-2">
              Explore local in-person training courses in your area by category,
              skill level, or industry.
            </p>
          </div>

          {/* Step 1 */}
          <div className="flex flex-col items-center text-center p-3">
            <div className="mb-2 flex h-8 w-8 items-center justify-center rounded-full bg-white text-black">
              1
            </div>
            <h4 className="font-semibold">Browse</h4>
            <p className="mt-1 text-sm">
              Search by category, skill level, or industry to find the best
              training near you.
            </p>
          </div>

          {/* Step 2 */}
          <div className="flex flex-col items-center text-center p-3">
            <div className="mb-2 flex h-8 w-8 items-center justify-center rounded-full bg-primary bg-white text-black">
              2
            </div>
            <h4 className="font-semibold">Book</h4>
            <p className="mt-1 text-sm">
              Read reviews, check instructor credentials, and compare course
              details.
            </p>
          </div>

          {/* Step 3 */}
          <div className="flex flex-col items-center text-center p-3">
            <div className="mb-2 flex h-8 w-8 items-center justify-center rounded-full bg-primary bg-white text-black">
              3
            </div>
            <h4 className="font-semibold">Learn</h4>
            <p className="mt-1 text-sm">
              Sign up, show up, and gain real skills with hands-on, expert-led
              training.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
