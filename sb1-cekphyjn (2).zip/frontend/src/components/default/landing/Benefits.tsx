import React from 'react';

const Benefits: React.FC = () => {
  return (
    <section className="py-5 lg:py-20 bg-background section-half">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12 lg:mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
            Real Skills. Real Instructors. Real Results.
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            The top reasons professionals trust us for real-world
            skill-building.
          </p>
        </div>

        {/* Benefit Cards - Responsive Grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {/* Card 1 */}
          <div className="rounded-lg border p-6 bg-card hover:shadow-lg transition-shadow dark-panel text-center border-radius-16">
            <h3 className="text-lg font-semibold md:text-xl">
              Hands-On Learning That Sticks.
            </h3>
            <p className="mt-2 text-sm text-muted-foreground md:text-base">
              Forget passive learning. In-person courses give you the experience
              and confidence you need to apply skills.
            </p>
          </div>

          {/* Card 2 */}
          <div className="rounded-lg border p-6 bg-card hover:shadow-lg transition-shadow dark-panel text-center border-radius-16">
            <h3 className="text-lg font-semibold md:text-xl">
              Learn by Doing, Not Just Watching.
            </h3>
            <p className="mt-2 text-sm text-muted-foreground md:text-base">
              Find training in high-demand industries, from skilled trades to
              professional certifications.
            </p>
          </div>

          {/* Card 3 */}
          <div className="rounded-lg border p-6 bg-card hover:shadow-lg transition-shadow dark-panel text-center border-radius-16">
            <h3 className="text-lg font-semibold md:text-xl">
              Skills That Get You Hired. Fast.
            </h3>
            <p className="mt-2 text-sm text-muted-foreground md:text-base">
              Discover training programs in high-demand industries that lead to
              real job opportunities and career growth.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Benefits;
