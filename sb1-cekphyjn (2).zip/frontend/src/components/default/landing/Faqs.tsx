import React from 'react';

const faqs = [
  {
    question: 'How is Training Booker different from Udemy or Coursera?',
    answer:
      'Online courses leave you stuck behind a screen. We connect you with hands-on, in-person training that actually helps you build skills and advance your career. No more guessing. No more wasting time.',
  },
  {
    question: 'Do I book courses directly on Training Booker?',
    answer:
      'We make it easy to find the perfect course. Just browse, compare, and book directly with the instructor—no hidden fees, no middleman.',
  },
  {
    question: 'Is there a cost to use Training Booker?',
    answer:
      'Absolutely! Searching and comparing courses is 100% free. Some instructors even offer free trial classes, so you can try before you buy!',
  },
];

const Faqs: React.FC = () => {
  return (
    <section className="py-12 bg-background text-foreground section-half">
      <div className="mx-auto max-w-7xl px-4">
        {/* Section Heading */}
        <h2 className="text-center text-3xl font-bold md:text-4xl">
          Frequently Asked Questions
        </h2>

        {/* FAQ List */}
        <div className="mt-8 space-y-6">
          {faqs.map((faq, index) => (
            <div key={index}>
              <h3 className="text-base font-semibold md:text-lg">
                {faq.question}
              </h3>
              <p className="mt-2 text-sm text-muted-foreground md:text-base">
                {faq.answer}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Faqs;
