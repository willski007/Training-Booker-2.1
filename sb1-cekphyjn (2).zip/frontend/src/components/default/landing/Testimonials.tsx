import React from 'react';
import BlockTestimonial from '../global/BlockTestimonial'; // Update path if needed

const Reviews: React.FC = () => {
  return (
    <section className="py-5 bg-background text-foreground">
      <div className="mx-auto max-w-7xl px-4 text-center">
        {/* Heading */}
        <h2 className="text-3xl font-bold md:text-4xl">
          Here's What Students Are Saying
        </h2>

        {/* Grid of Testimonials */}
        <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, index) => (
            <BlockTestimonial key={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;
