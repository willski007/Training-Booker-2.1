import React from 'react';
import CardCourse from '../global/CardCourse';

const Spotlight: React.FC = () => {
  return (
    <section className="py-5 lg:py-20 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
            Top In-Demand Courses Chosen for You
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Discover the most popular hands-on courses learners love. Taught by
            industry experts, designed to help you grow.
          </p>
        </div>

        {/* Grid of Courses - Responsive Grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {[...Array(8)].map((_, index) => (
            <CardCourse key={index} />
          ))}
        </div>

        {/* "Explore All Classes" Button */}
        <div className="mt-12 text-center">
          <button className="button-primary px-8 py-3 text-base font-medium">
            Explore All Classes
          </button>
        </div>
      </div>
    </section>
  );
};

export default Spotlight;
