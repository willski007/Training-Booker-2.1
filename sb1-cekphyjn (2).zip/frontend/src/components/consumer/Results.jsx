import React, { useState } from 'react';
// Adjust these import paths based on your actual folder structure:
import Header from '../default/global/Header';
import ResultsSidebar.tsx from '../results/ResultsSidebar.tsx';
import CardCourse from './CardCourse';


// Categories for multi-select
const categoriesList = [
  'Business',
  'Technology and AI',
  'Medical',
  'Skilled Trades',
  'Wellness',
  'Education',
  'Creative',
  'Security',
  'Language',
];

function Results() {
  // Track which categories are selected
  const [selectedCategories, setSelectedCategories] = useState([]);

  // Track courses (in real use, fetch from API or database)
  const [courses] = useState(dummyCourses);

  // Track sort option
  const [sortBy, setSortBy] = useState('best');

  // Example location value (could come from props, context, or user input)
  const location = 'Orlando, FL';

  // Handle toggling categories on/off
  const handleCategoryToggle = (category) => {
    setSelectedCategories((prev) =>
      prev.includes(category)
        ? prev.filter((cat) => cat !== category)
        : [...prev, category]
    );
  };

  // Filter and sort logic can be expanded as needed
  const filteredCourses = courses.filter((course) => {
    // If no categories selected, show all
    if (selectedCategories.length === 0) return true;
    // Example: match if the title includes any selected category
    // Adjust to your actual filtering rules
    return selectedCategories.some((cat) =>
      course.title.toLowerCase().includes(cat.toLowerCase())
    );
  });

  // Example sort logic
  const sortedCourses = [...filteredCourses].sort((a, b) => {
    if (sortBy === 'best') {
      return 0; // No special ordering
    } else if (sortBy === 'priceLow') {
      // Custom logic for sorting by price (requires price data)
      return 0;
    } else if (sortBy === 'priceHigh') {
      // Custom logic for sorting by price descending
      return 0;
    }
    return 0;
  });

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Site Header */}
      <Header />

      <div className="container mx-auto py-8">
        {/* Categories Menu (multi-select) */}
        <div className="flex flex-wrap gap-2 mb-4">
          {categoriesList.map((category) => (
            <button
              key={category}
              type="button"
              onClick={() => handleCategoryToggle(category)}
              className={`px-4 py-2 rounded-full transition-colors ${
                selectedCategories.includes(category)
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Main layout: Sidebar + Results */}
        <div className="flex gap-4">
          {/* Left Sidebar: Search Filter */}
          <aside className="w-64">
            <SearchFilter />
          </aside>

          {/* Right Section: Course Results */}
          <main className="flex-1">
            {/* Title and Sort Options */}
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-xl font-semibold">
                {sortedCourses.length
                  ? `${sortedCourses.length} courses in ${location}`
                  : `No courses in ${location}`}
              </h1>
              <div>
                <label htmlFor="sortBy" className="mr-2 font-medium">
                  Sort by:
                </label>
                <select
                  id="sortBy"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="border border-gray-300 rounded px-2 py-1"
                >
                  <option value="best">Best Match</option>
                  <option value="priceLow">Price: Low to High</option>
                  <option value="priceHigh">Price: High to Low</option>
                </select>
              </div>
            </div>

            {/* Course List */}
            <div className="flex flex-col gap-4">
              {sortedCourses.map((course) => (
                <CardCourse
                  key={course.id}
                  title={course.title}
                  location={course.location}
                  startDate={course.startDate}
                  hours={course.hours}
                  imageUrl={course.imageUrl}
                />
              ))}
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}

export default Results;
