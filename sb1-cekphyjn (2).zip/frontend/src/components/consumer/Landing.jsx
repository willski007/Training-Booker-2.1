import React from 'react';
import AboveTheFold from '../default/landing/AboveTheFold';
import Problem from '../default/landing/Problem';
import Solution from '../default/landing/Solution';
import Benefits from '../default/landing/Benefits';
import Spotlight from '../default/landing/Spotlight';
import HowItWorks from '../default/landing/HowItWorks';
import Testimonials from '../default/landing/Testimonials';
import Faqs from '../default/landing/Faqs';
import Cta from '../default/landing/Cta';

const Landing = () => {
  return (
    <div className="container mx-auto px-4">
      <AboveTheFold />
      <Problem />
      <Solution />
      <Benefits />
      <Spotlight />
      <HowItWorks />
      <Testimonials />
      <Faqs />
      <Cta />
    </div>
  );
};

export default Landing;
