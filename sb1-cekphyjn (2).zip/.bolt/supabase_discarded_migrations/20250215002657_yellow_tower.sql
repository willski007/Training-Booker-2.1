/*
  # Users Table for Training Marketplace

  1. New Tables
    - `user_roles` enum type for role management
    - `users` table with the following columns:
      - `id` (uuid, primary key) - matches Supabase auth.users id
      - `full_name` (text, required)
      - `email` (text, unique, required) - matches auth.users email
      - `role` (user_roles enum, required)
      - `created_at` (timestamptz, auto-set)
      - `updated_at` (timestamptz, auto-set)
      - `deleted_at` (timestamptz, null by default for soft deletes)

  2. Security
    - Enable RLS on users table
    - Policies for:
      - Users can read their own profile
      - Users can read instructor profiles
      - Admins can read all profiles
      - Users can update their own profile
      - Admins can update any profile
      - Only admins can soft delete profiles
*/

-- Create the role enum type
CREATE TYPE user_roles AS ENUM ('learner', 'instructor', 'admin');

-- Create the users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  full_name text NOT NULL,
  email text NOT NULL UNIQUE,
  role user_roles NOT NULL DEFAULT 'learner',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz,
  CONSTRAINT valid_email CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

-- Create index for email lookups
CREATE INDEX IF NOT EXISTS users_email_idx ON users (email);

-- Create index for soft deletes
CREATE INDEX IF NOT EXISTS users_deleted_at_idx ON users (deleted_at) WHERE deleted_at IS NOT NULL;

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own profile"
  ON users FOR SELECT
  TO authenticated
  USING (auth.uid() = id AND deleted_at IS NULL);

CREATE POLICY "Users can read instructor profiles"
  ON users FOR SELECT
  TO authenticated
  USING (role = 'instructor' AND deleted_at IS NULL);

CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);