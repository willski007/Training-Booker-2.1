/*
  # Bookings Table for Training Marketplace

  1. New Tables
    - `booking_status` enum type for booking states
    - `bookings` table with the following columns:
      - `id` (uuid, primary key)
      - `course_id` (uuid, references courses)
      - `user_id` (uuid, references users)
      - `status` (booking_status enum, required)
      - `payment_intent_id` (text, for Stripe)
      - `amount_paid` (integer, in cents)
      - `created_at` (timestamptz, auto-set)
      - `updated_at` (timestamptz, auto-set)
      - `cancelled_at` (timestamptz)

  2. Security
    - Enable RLS on bookings table
    - Policies for:
      - Users can read their own bookings
      - Instructors can read bookings for their courses
      - Admins can read all bookings
*/

CREATE TYPE booking_status AS ENUM ('pending', 'confirmed', 'cancelled', 'completed');

CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id),
  user_id uuid NOT NULL REFERENCES users(id),
  status booking_status NOT NULL DEFAULT 'pending',
  payment_intent_id text UNIQUE,
  amount_paid integer CHECK (amount_paid >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  cancelled_at timestamptz,
  UNIQUE(course_id, user_id, status)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS bookings_user_id_idx ON bookings (user_id);
CREATE INDEX IF NOT EXISTS bookings_course_id_idx ON bookings (course_id);
CREATE INDEX IF NOT EXISTS bookings_status_idx ON bookings (status);
CREATE INDEX IF NOT EXISTS bookings_payment_intent_id_idx ON bookings (payment_intent_id);

-- Enable Row Level Security
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Instructors can read course bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = bookings.course_id
      AND courses.instructor_id = auth.uid()
    )
  );