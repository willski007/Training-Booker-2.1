/*
  # Courses Table for Training Marketplace

  1. New Tables
    - `courses` table with the following columns:
      - `id` (uuid, primary key)
      - `instructor_id` (uuid, references users)
      - `title` (text, required)
      - `description` (text, required)
      - `price` (integer, required, in cents)
      - `capacity` (integer, required)
      - `location` (text, required)
      - `start_date` (timestamptz, required)
      - `end_date` (timestamptz, required)
      - `created_at` (timestamptz, auto-set)
      - `updated_at` (timestamptz, auto-set)
      - `deleted_at` (timestamptz, null by default)

  2. Security
    - Enable RLS on courses table
    - Policies for:
      - Anyone can read active courses
      - Instructors can CRUD their own courses
      - Admins can CRUD all courses
*/

CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instructor_id uuid NOT NULL REFERENCES users(id),
  title text NOT NULL,
  description text NOT NULL,
  price integer NOT NULL CHECK (price >= 0),
  capacity integer NOT NULL CHECK (capacity > 0),
  location text NOT NULL,
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz,
  CONSTRAINT valid_dates CHECK (end_date > start_date)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS courses_instructor_id_idx ON courses (instructor_id);
CREATE INDEX IF NOT EXISTS courses_start_date_idx ON courses (start_date);
CREATE INDEX IF NOT EXISTS courses_deleted_at_idx ON courses (deleted_at) WHERE deleted_at IS NULL;

-- Enable Row Level Security
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can read active courses"
  ON courses FOR SELECT
  TO authenticated
  USING (deleted_at IS NULL AND start_date > now());

CREATE POLICY "Instructors can manage their courses"
  ON courses FOR ALL
  TO authenticated
  USING (instructor_id = auth.uid())
  WITH CHECK (instructor_id = auth.uid());